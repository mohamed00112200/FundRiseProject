# FundRise

A modern crowdfunding platform built with Vanilla HTML, CSS, and JavaScript, powered by `json-server` as a mock REST API.

## Overview

FundRise is a client-side crowdfunding project created for a Modern JavaScript assignment. It supports three user roles:

- Guest users can browse approved campaigns and filter them by search and category.
- Registered users can create campaigns, edit their own campaign details, support campaigns with pledges, and review their pledge history.
- Admin users can manage users, approve or reject campaigns, delete campaigns, and review all pledges from a sidebar-based dashboard.

## Features

### Guest
- Browse approved campaigns only
- Search by title or description
- Filter by category

### Registered User
- Register and login
- Create new campaigns
- Edit owned campaigns
- Upload campaign images
- Support campaigns with a mock payment confirmation flow
- View personal pledge history

### Admin
- View all users
- Ban and unban users
- Review all campaigns
- Approve, reject, or delete campaigns
- Review all pledges
- Switch dashboard sections from a sidebar

## Tech Stack

- HTML5
- CSS3
- Vanilla JavaScript (ES Modules)
- JSON Server

## Project Structure

```text
.
├── css/
│   ├── components.css
│   ├── main.css
│   └── pages/
│       ├── admin.css
│       ├── auth.css
│       ├── form.css
│       └── home.css
├── js/
│   ├── config.js
│   ├── main.js
│   ├── utils.js
│   ├── pages/
│   │   ├── CreateCampaignPage.js
│   │   ├── HomeAdminPage.js
│   │   ├── HomeUserPage.js
│   │   ├── LandingPage.js
│   │   ├── LoginPage.js
│   │   └── RegisterPage.js
│   └── services/
│       ├── adminService.js
│       ├── apiService.js
│       ├── authService.js
│       ├── campaignService.js
│       └── pledgeService.js
├── pages/
│   ├── CreateCampaign.html
│   ├── HomeAdmin.html
│   ├── HomeUser.html
│   ├── login.html
│   └── register.html
├── db.json
├── index.html
└── package.json
```

## Getting Started

### 1. Install dependencies

```bash
npm install
```

### 2. Start the mock API

```bash
npm start
```

The API runs at:

```text
http://localhost:3000
```

### 3. Open the frontend

Open `index.html` in your browser.

Main pages:

- `index.html`
- `pages/login.html`
- `pages/register.html`
- `pages/HomeUser.html`
- `pages/CreateCampaign.html`
- `pages/HomeAdmin.html`

## Demo Accounts

### Admin

- Email: `admin@fundrise.com`
- Password: `admin123`

### User

- Email: `m@m.com`
- Password: `123`

## Assignment Coverage

This project covers the required assignment functionality:

- Role-based access
- CRUD operations with `fetch()`
- Campaign approval workflow
- Pledge support flow
- Base64 image upload
- Professional landing page and dashboards

## Bonus Requirements

- Mock payment flow implemented with a confirmation dialog before a pledge is saved
- Local Git workflow prepared for version control
- GitHub-ready README for project presentation

## Git And GitHub

### Local Git

Initialize the repository locally:

```bash
git init -b main
git add .
git commit -m "Initial crowdfunding platform submission"
```

### Push To GitHub

Create an empty GitHub repository, then connect and push:

```bash
git remote add origin https://github.com/<your-username>/<your-repository>.git
git push -u origin main
```

### Suggested Commit History

If you want a cleaner history for submission, use commit messages like:

- `setup project structure and shared services`
- `build authentication and registration flow`
- `build user dashboard and campaign management`
- `build admin dashboard and approval workflow`
- `improve responsive design and landing page`
- `add mock payment confirmation and project documentation`

## Notes

- This project uses `json-server` as a mock backend for development and demonstration.
- IDs may be stored as strings or numbers depending on data history, so the frontend was written to handle both safely.
- The current design uses a green brand palette for a cleaner and more professional GitHub-ready presentation.

## Author

Mohamed Lotfy
